using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Azure.Storage.Blobs;
using FileFunction.Models;
using System.Text;
using System.Collections.Generic;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs.Specialized;
using Microsoft.Extensions.FileProviders;
using System.Linq;

namespace FileFunction.Functions
{
    public static class SplitFileFunction
    {
        [FunctionName("SplitFileFunction")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
            [Blob("orders", Connection = "AzureWebJobsStorage")] BlobContainerClient container,
            ILogger log)
        {
            log.LogInformation("Processing a request");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var request = JsonConvert.DeserializeObject<FileRequest>(requestBody);
            var fileName = request.fileName;

            Console.WriteLine($"Received filename={fileName}");
            

            
            //await new BlobClient(new Uri(fileName)).DownloadToAsync()

            await container.CreateIfNotExistsAsync();
          
            //List<string> names = new List<string>();
            BlobItem inputBlob = null;

            await foreach (BlobItem blob in container.GetBlobsAsync())
            {
                if (blob.Name.Equals(fileName, StringComparison.OrdinalIgnoreCase)) {
                    inputBlob = blob;
                    break;
                }
                //names.Add(blob.Name);
            }

            Console.WriteLine($"Found Blob {inputBlob.Name}");
            var blobClient = container.GetBlockBlobClient(inputBlob.Name);
            FileStream fileStream = File.OpenWrite("tmp333.txt");
            await blobClient.DownloadToAsync(fileStream);
            Console.WriteLine("downloaded to tmp333.txt");
            fileStream.Close();
            FileStream readFileStream = File.OpenRead("tmp333.txt");

            StreamReader reader = new StreamReader(readFileStream);
            string content =  reader.ReadToEnd();
            Console.WriteLine("Read the contents");
            Console.WriteLine(content);
            readFileStream.Close();

            var outputBlob = container.GetBlobClient($"{inputBlob.Name}_{DateTime.UtcNow:yyyy_MM_dd_HH_mm_ss}.txt");

            
            List<String> outputLines = new List<String>();
            Console.WriteLine("Uploading the contents");
            foreach (string line in content.Split(new char[] { '\r', '\n' })) {
                Console.WriteLine($"line: {line}");
                if (line == null || line.Length == 0) continue;
                String itemId, itemName, itemQuantity, itemPrice, itemTotal;
                String[] itemDetails = line.Split(new char[] { ',' });  
                itemId = itemDetails[0];
                itemName = itemDetails[1];
                itemQuantity = itemDetails[2];
                itemPrice = itemDetails[3]; 
                itemTotal = itemDetails[4];
                String outputline = String.Join(",", itemName, itemQuantity, itemPrice, itemTotal);
                
                outputLines.Add(outputline);
            }

            using var output = new MemoryStream(Encoding.UTF8.GetBytes(String.Join("\n", outputLines)));

            await outputBlob.UploadAsync(output);

            return new OkObjectResult(inputBlob.Name);
        }
    }
}
