using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Azure.Storage.Blobs;
using FileFunction.Models;
using System.Text;

namespace FileFunction.Functions
{
    public static class BlobOutputFunction
    {
        [FunctionName("BlobOutputFunction")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
            [Blob("orders", Connection = "AzureWebJobsStorage")] BlobContainerClient container,
            ILogger log)
        {
            log.LogInformation("Processing a request");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var request = JsonConvert.DeserializeObject<OrderRequest>(requestBody);

            var Order = new Order
            {
                Id = Guid.NewGuid(),
                Name = request.Name,
                Price = request.Price,
                Quantity = request.Quantity,
                Total = request.Price * request.Quantity
            };

            await container.CreateIfNotExistsAsync();
            var blob = container.GetBlobClient($"order_{Order.Id}_{DateTime.UtcNow:yyyy_MM_dd}.txt");

            using var orderStream = new MemoryStream(Encoding.UTF8.GetBytes(Order.ToString()));

            await blob.UploadAsync(orderStream);


            return new OkObjectResult(Order.ToString());
        }
    }
}
