﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileFunction.Models
{
    public class FileRequest
    {
        public string fileName { get; set; }
    }
}
